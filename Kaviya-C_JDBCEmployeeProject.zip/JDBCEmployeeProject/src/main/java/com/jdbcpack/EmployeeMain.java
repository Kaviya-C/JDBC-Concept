package com.jdbcpack;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.SQLException;
import java.util.Scanner;
import com.jdbc.model.Employee;
//import com.jdbc.services.EmployeeInterface;
import com.jdbc.services.EmployeeInterfaceImplement;

public class EmployeeMain
{
	public static void main(String[] args) throws IOException 
	{				
		// TODO Auto-generated method stub
		EmployeeInterfaceImplement empInterface=new EmployeeInterfaceImplement();
		String repeat=null;
		BufferedReader bufferedReader= new BufferedReader(new InputStreamReader(System.in)); 
		try (Scanner input = new Scanner(System.in)) 
		{
			do 
			{
				System.out.println("1---addEmployee \n"
						+ "2---updateEmployee \n"
						+ "3--deleteEmployee\n "
						+ "4--displayeEmployeeDetails \n"
						+"5--findEmployee by Id \n"
						+ "6-exit");

				System.out.println("enter the option");

				int option =input.nextInt();
				switch(option)
				{
				case 1:
					System.out.println("enter the count of how many employee data u want to add??");
					int count=input.nextInt();
					for(int index=0;index<count;index++)
					{
						System.out.println("enter the employee id: ");
						int id=input.nextInt();
						System.out.println("enter the employee age: ");
						int age=input.nextInt();
						System.out.println("enter the employee name: ");
						String name=input.next();
						System.out.println("enter the employee salary: ");
						double empSalary=input.nextDouble();
						System.out.println("enter the employee designation: ");
						String role=input.next();
						System.out.println("enter the employee company name: ");
						String company=input.next();
						Employee employee = new Employee(id,age,name,empSalary,role,company);
						try 
						{
							empInterface.addEmployee(employee);
						}

						catch (SQLException e)
						{
							System.out.println("adding employee -->"+e.getMessage());
						}
					}
					break;

				case 2:
					System.out.println("enter the employee id to modify");
					int modifyeid=input.nextInt();
					System.out.println("enter the property  which you want to change?");
					String property=input.next();
					Employee modifyEmployee = new Employee();
					if(property.equals("name"))
					{
						System.out.println("enter the new name of the employee:");
						modifyEmployee.setEmpName(input.next());
					}
					if(property.equals("salary"))
					{
						System.out.println("enter the new salary of the employee: ");
						modifyEmployee.setEmpSalary(input.nextDouble());
					}
					if(property.equals("role"))
					{
						System.out.println("enter the updated role of the employee: ");
						modifyEmployee.setEmpRole(input.next());
					}
					if(property.equals("age"))
					{
						System.out.println("enter the new age of the employee: ");
						modifyEmployee.setEmpAge(input.nextInt());
					}
					if(property.equals("company"))
					{
						System.out.println("enter the new company of the employee: ");
						modifyEmployee.setEmpCompanyName(input.next());
					}
					try 
					{
						int r=empInterface.updateEmployee(modifyEmployee, modifyeid,property);
						System.out.println(r);
						if(r>=1)
							System.out.println("Updated successfuly");
					} catch (SQLException e) {
						System.out.println("update student -->"+e.getMessage());
					}
					break;
				case 3: 
					try 
					{
						int empid=0;
						empInterface.deleteEmployee(empid);

					}
					catch(SQLException e)
					{
						System.out.println("deleting employee---->"+e.getMessage());
					}
					break;
				case 4:
					try 
					{
						empInterface.displayEmployeeDetails();
					} 
					catch (SQLException e)
					{
						System.out.println("Display the employee details -->"+e.getMessage());
					}
					break;
				case 5:
					try 
					{
						int empId=0;
						empInterface.findEmployeeById(empId);
					}
					catch(SQLException e)
					{
						System.out.println("finding that employee have some error...\n"+e.getMessage());
					}
					break;
				default: System.out.println("enter the valid option");
				break;
				}
				System.out.println("do you wish to continue say yes?");
				repeat=bufferedReader.readLine();
				System.out.println(repeat);
			}while(repeat.equals("yes"));
		}
	}

}


