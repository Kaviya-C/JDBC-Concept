package com.jdbc.model;

public class Employee 
{
	private int empId;
	private int empAge;
	private String empName;
	private double empSalary;
	private String empRole;
	private String empCompanyName;

	public Employee()
	{
		//select distinct empId,empAge,empName,empSalary,empRole from employee where empId=?" );
	}
	public Employee(int empId,int empAge, String empName, double empSalary,String empRole,String empCompanyName) 
	{
		super();
		this.empId = empId;
		this.empAge=empAge;
		this.empName = empName;
		this.empSalary = empSalary;
		this.empRole=empRole;
		this.empCompanyName=empCompanyName;
	}
	public int getEmpId() 
	{
		return empId;
	}
	public void setEmpId(int empId)
	{
		this.empId = empId;
	}
	public int getEmpAge() {
		return empAge;
	}
	public void setEmpAge(int empAge) 
	{
		this.empAge=empAge;
	}
	public String getEmpName() 
	{
		return empName;
	}
	public void setEmpName(String empName) 
	{
		this.empName = empName;
	}
	public double getEmpSalary() 
	{
		return empSalary;
	}
	public void setEmpSalary(double empSalary) 
	{
		this.empSalary = empSalary;
	}
	public String getEmpRole() 
	{
		return empRole;
	}
	public void setEmpRole(String empRole) 
	{
		this.empRole=empRole;
	}
	public String getEmpCompanyName() 
	{
		return empCompanyName;
	}
	public void setEmpCompanyName(String empCompanyName) 
	{
		this.empCompanyName=empCompanyName;
	}
	
	@Override
	public String toString() 
	{
		return "Employee [empId=" + empId + ", empAge=" + empAge + ", empName=" + empName + ", empSalary=" + empSalary
				+ ", empRole=" + empRole + ", empCompanyName=" + empCompanyName + "]";
	}
}




/*
 * @Override public String toString() { return "Student [sid=" + sid + ", name="
 * + name + ", marks=" + marks + "]"; }
 */

