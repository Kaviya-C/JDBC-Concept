package com.jdbc.preparestatement;
import java.sql.*;
import java.util.Scanner;
public class EmployeePrepareStatement {

	public static void main(String[] args) throws ClassNotFoundException, SQLException 
	{
		try (Scanner input = new Scanner(System.in)) 
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/JDBCDatabase","root","root123");
			PreparedStatement prepStmt =con.prepareStatement("insert into empoyee values(?,?,?,?,?)");
			prepStmt.setInt(1,input.nextInt());
			prepStmt.setString(2,input.next());
			prepStmt.setDouble(3,input.nextDouble());
			prepStmt.setInt(4,input.nextInt());
			prepStmt.setString(5,input.next());
			int res=prepStmt.executeUpdate();
			if(res==1)
			{
				System.out.println("Inserted............");
			}
		}
	}

}

/*
 * PreparedStatement stmt
 * =con.prepareStatement("update Employee set name=?,salary=? where empId=?");
 * stmt.setString(1,"vishnu kumar"); stmt.setDouble(2,75.00);
 * stmt.setString(3,"7547564532"); stmt.setInt(4,1000); int
 * res=stmt.executeUpdate();//2 if(res>=1) {
 * System.out.println("Updated............"); }
 */


