package com.jdbc.services;

import java.sql.SQLException;
import com.jdbc.model.Employee;

public interface EmployeeInterface 
{
	void addEmployee(Employee employee) throws SQLException;
	
	int updateEmployee(Employee employee , int empId,String property) throws SQLException;
	
	void deleteEmployee(int empId) throws SQLException;
	
	Employee findEmployeeById(int empId) throws SQLException;
	
	void displayEmployeeDetails() throws SQLException;

	Employee findEmployeeByIdUpdate(int empId) throws SQLException;
}



