package com.jdbc.services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;
import com.jdbc.model.Employee;
import com.jdbcpack.EmpCustomConnection;

public class EmployeeInterfaceImplement implements EmployeeInterface
{
	Connection connection=null;
	PreparedStatement pstatement=null;
	Scanner input=new Scanner(System.in);
	public EmployeeInterfaceImplement()
	{
		connection=EmpCustomConnection.getCustConnection();
	}

	@Override
	public void addEmployee(Employee employee) throws SQLException 
	{

		pstatement=connection.prepareStatement
				("insert into employee values(?,?,?,?,?,?)");
		pstatement.setInt(1, employee.getEmpId());
		pstatement.setInt(2, employee.getEmpAge());
		pstatement.setString(3, employee.getEmpName());
		pstatement.setDouble(4,employee.getEmpSalary());
		pstatement.setString(5, employee.getEmpRole());
		pstatement.setString(6, employee.getEmpCompanyName());
		int result=pstatement.executeUpdate();
		if(result==1)
		{
			System.out.println("data inserted successfully");
		}		
	}
	@Override
	public int updateEmployee(Employee employee, int empId,String property) throws SQLException 
	{

		// TODO Auto-generated method stub
		Employee employee1=findEmployeeByIdUpdate(empId);
		if(property.equals("name"))
			employee1.setEmpName(employee.getEmpName());
		if(property.equals("salary"))
			employee1.setEmpSalary(employee.getEmpSalary());
		if(property.equals("role"))
			employee1.setEmpRole(employee.getEmpRole());
		if(property.equals("age"))
			employee1.setEmpAge(employee.getEmpAge());
		if(property.equals("company"))
			employee1.setEmpCompanyName(employee.getEmpCompanyName());
		pstatement=connection.prepareStatement("update employee set empName=?,empAge=?,"
				+ "empSalary=?,empRole=?,empCompany=? where empId=? ");
		pstatement.setString(1,employee1.getEmpName());
		pstatement.setInt(2, employee1.getEmpAge());
		pstatement.setDouble(3, employee1.getEmpSalary());
		pstatement.setString(4, employee1.getEmpRole());
		pstatement.setString(5, employee1.getEmpCompanyName());
		pstatement.setInt(6, empId);
		int res=pstatement.executeUpdate();
		return res;
	}

	@Override
	public void deleteEmployee(int eId) throws SQLException 
	{
		pstatement=connection.prepareStatement("Delete from employee where empId=?");
		System.out.println("enter the employee id which u want to delete?? ");
		pstatement.setInt(1,input.nextInt());
		int del=pstatement.executeUpdate();
		if(del>=1) 
		{
			System.out.println("entered employee record was deleted..!");
		}
	}

	@Override
	public Employee findEmployeeByIdUpdate(int empId) throws SQLException 
	{
		System.out.println(empId);
		pstatement=connection.prepareStatement("select *from employee where empId=?");
		pstatement.setInt(1,empId);
		ResultSet rs=pstatement.executeQuery();
		rs.next();
		System.out.println(rs);
		Employee employee=new Employee(rs.getInt(1),rs.getInt(2),rs.getString(3),
				rs.getDouble(4),rs.getString(5),rs.getString(6));
		System.out.println(employee);
		return employee;
	}


	@Override
	public Employee findEmployeeById(int empId) throws SQLException 
	{
		// TODO Auto-generated method stub
		pstatement=connection.prepareStatement("select *from employee where empId=?");
		System.out.println("enter the employee id: ");
		pstatement.setInt(1,input.nextInt());
		ResultSet rs=pstatement.executeQuery();
		rs.next();
		Employee employee=new Employee(rs.getInt(1),rs.getInt(2),rs.getString(3),
				rs.getDouble(4), rs.getString(5),rs.getString(6));
		System.out.println(employee);
		return employee;
	}
	@Override
	public void displayEmployeeDetails() throws SQLException 
	{
		// TODO Auto-generated method stub
		pstatement=connection.prepareStatement("select *from employee");
		ResultSet resultSet = pstatement.executeQuery();
		while(resultSet.next())		//next() --brings the cursor to the first record----returns true
		{
			int id=resultSet.getInt("empId");
			int age=resultSet.getInt("empAge");
			String name=resultSet.getString("empName");
			double salary=resultSet.getDouble("empSalary");
			String role=resultSet.getString("empRole");
			String company=resultSet.getString("empCompany");
			Employee employee = new Employee(id,age,name,salary,role, company);
			System.out.println(employee);
		}

	}

}

